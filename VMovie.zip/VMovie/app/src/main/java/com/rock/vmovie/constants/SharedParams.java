package com.rock.vmovie.constants;

/**
 * Created by Rock on 2017/6/15.
 */

public class SharedParams {

    public static final String NAME = "VMovie";

    public static final String FIRST_USE = "FirstUse";

}
