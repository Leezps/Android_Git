package com.rock.vmovie.activity;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.support.annotation.IdRes;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.rock.vmovie.BaseActivity;
import com.rock.vmovie.R;
import com.rock.vmovie.fragments.BehindFragment;
import com.rock.vmovie.fragments.FirstPageFragment;
import com.rock.vmovie.fragments.SeriesFragment;

public class MainActivity extends BaseActivity implements RadioGroup.OnCheckedChangeListener, View.OnClickListener {


    private FirstPageFragment mFirstPage;
    private SeriesFragment mSeries;
    private BehindFragment mBehind;
    private RadioGroup mController;
    private View mCover;
    private RadioButton mFirstPageController;
    private ImageView mCloseCover;
    private RadioButton mSeriesController;
    private RadioButton mBehindController;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_main;
    }

    @Override
    protected void initView() {
        /**
         * 动态加载Fragment流程
         *      ① 获取一个FragmentManager
         *      ② 开启一个FragmentTransaction
         *      ③ 添加动作
         *      ④ 提交事务
         */
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction transaction = fm.beginTransaction();
        // 动作
        mFirstPage = new FirstPageFragment();
        mSeries = new SeriesFragment();
        mBehind = new BehindFragment();
        // 将页面添加进来
        transaction.add(R.id.main_container, mFirstPage).add(R.id.main_container, mSeries).add(R.id.main_container, mBehind);
        // 将所有页面隐藏
        transaction.hide(mFirstPage).hide(mSeries).hide(mBehind);

        transaction.commit();

        // 初始化控件
        mController = (RadioGroup) findViewById(R.id.main_controller);
        mController.setOnCheckedChangeListener(this);

        // 初始化覆盖层
        mCover = findViewById(R.id.main_cover);

        mFirstPageController = (RadioButton) findViewById(R.id.main_controller_firstpage);
        mFirstPageController.setChecked(true);
        mSeriesController = (RadioButton) findViewById(R.id.main_controller_series);
        mBehindController = (RadioButton) findViewById(R.id.main_controller_behind);
        mFirstPageController.setOnClickListener(this);
        mSeriesController.setOnClickListener(this);
        mBehindController.setOnClickListener(this);

        mCloseCover = (ImageView) findViewById(R.id.main_close_cover);
        mCloseCover.setOnClickListener(this);
    }

    public void openCover() {
        mCover.setVisibility(View.VISIBLE);
        // 添加动画  关闭按钮的放大动画，控制按钮的顺序显示动画
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(mCloseCover, "scaleX", 0, 0.8f, 1, 1.2f, 1);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(mCloseCover, "scaleY", 0, 0.8f, 1, 1.2f, 1);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(scaleX).with(scaleY);
        animatorSet.setDuration(300);
        animatorSet.start();

        Animation firstIn = AnimationUtils.loadAnimation(this, R.anim.firstpage_in);
        Animation seriesIn = AnimationUtils.loadAnimation(this, R.anim.series_in);
        Animation behindIn = AnimationUtils.loadAnimation(this, R.anim.behind_in);
        mFirstPageController.startAnimation(firstIn);
        mSeriesController.startAnimation(seriesIn);
        mBehindController.startAnimation(behindIn);

    }

    @Override
    public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {

        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction transaction = fm.beginTransaction();

        switch (checkedId) {
            case R.id.main_controller_firstpage:
                transaction.hide(mBehind).hide(mSeries).show(mFirstPage);
                break;
            case R.id.main_controller_series:
                transaction.hide(mFirstPage).hide(mBehind).show(mSeries);
                break;
            case R.id.main_controller_behind:
                transaction.hide(mFirstPage).hide(mSeries).show(mBehind);
                break;
        }

        transaction.commit();
        closeCover();
    }

    public void closeCover() {
        mCover.setVisibility(View.GONE);
    }

    public void closeCoverWithAnim() {
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(mCloseCover, "scaleX", 1, 1.2f, 1, 0.8f, 0);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(mCloseCover, "scaleY", 1, 1.2f, 1, 0.8f, 0);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(scaleX).with(scaleY);
        animatorSet.setDuration(300);
        animatorSet.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                closeCover();
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
        animatorSet.start();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.main_close_cover:
                closeCoverWithAnim();
                break;
            case R.id.main_controller_firstpage:
            case R.id.main_controller_behind:
            case R.id.main_controller_series:
                closeCover();
                break;

        }
    }
}
