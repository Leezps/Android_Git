package com.rock.vmovie.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.rock.vmovie.R;

public class GuideActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);
    }
}
