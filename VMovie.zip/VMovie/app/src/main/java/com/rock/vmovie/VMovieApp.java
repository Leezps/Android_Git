package com.rock.vmovie;

import android.app.Application;

import org.xutils.x;

/**
 * Created by Rock on 2017/6/15.
 */

public class VMovieApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        // 初始化各种框架
        x.Ext.init(this);
        //
        x.Ext.setDebug(true);
    }
}
