package com.rock.vmovie.fragments;

import android.view.View;
import android.widget.ImageView;

import com.rock.vmovie.BaseFragment;
import com.rock.vmovie.R;
import com.rock.vmovie.activity.MainActivity;

/**
 * Created by Rock on 2017/6/15.
 */

public class BehindFragment extends BaseFragment implements View.OnClickListener {

    private ImageView mOpenCover;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_behind;
    }

    @Override
    protected void initView() {
        mOpenCover = (ImageView) findViewById(R.id.open_cover);
        mOpenCover.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.open_cover:
                // 打开Activity中的 cover menu
                /**
                 *   .cast 强制类型转换
                 *   .var 提取局部变量
                 */
                MainActivity mainActivity = (MainActivity) getActivity();
                mainActivity.openCover();
                break;
        }
    }
}
