package com.rock.vmovie.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.rock.vmovie.BaseActivity;
import com.rock.vmovie.R;
import com.rock.vmovie.constants.SharedParams;

public class SplashActivity extends BaseActivity implements Animation.AnimationListener {


    private ImageView mImage;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_splash;
    }

    @Override
    protected void initView() {
        mImage = (ImageView) findViewById(R.id.splash_bg);
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.splash_scale);
        // 设置动画监听
        animation.setAnimationListener(this);

        mImage.startAnimation(animation);

    }

    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {
        // 动画结束 决定页面跳转到主页还是导航页，需使用数据持久化技术
        SharedPreferences sdf = getSharedPreferences(SharedParams.NAME, Context.MODE_PRIVATE);
        boolean firstUse = sdf.getBoolean(SharedParams.FIRST_USE, true);
        if (firstUse) {
            // 跳转到导航页
            // 记录使用标识
            SharedPreferences.Editor editor = sdf.edit();
            editor.putBoolean(SharedParams.FIRST_USE,false);
            editor.apply();
            startActivity(new Intent(this,GuideActivity.class));
        }else{
            // 跳转到主页
            startActivity(new Intent(this,MainActivity.class));
        }

        finish();
    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}
